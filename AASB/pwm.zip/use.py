from pwm import PWM, PSSM

seqs = "ACCT ACGT ACGT ACAA ACCG".split()

P = PWM(seqs)

print(P.seq_mais_provavel("ACATACAGTACAT"))

PP = PSSM(seqs)

print(PP.seq_mais_provavel("ACATACAGTACAT"))
