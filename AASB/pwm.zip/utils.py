def sliding_window(seq, N = 3):
    return [seq[P : P + N] for P in range(len(seq) - N + 1)]
