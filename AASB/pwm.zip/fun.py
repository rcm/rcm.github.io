def f(x, *args, **kwargs):
    assert "pc" in kwargs
    pc = kwargs.get("pc", 0)
    return pc


def prod(*args):
    p = 1
    for x in args:
            p *= x
    return p

