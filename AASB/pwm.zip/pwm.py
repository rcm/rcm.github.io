from math import log2
from collections import Counter
from utils import sliding_window

def is_dna(s):
    assert all(x in "ACGT" for x in s), f"{s} não é DNA!"
    return True

def contar(coluna, pseudocount = 0):
    return {x : coluna.count(x) + pseudocount for x in "ACGT"}

def faz_contagens(seqs, pseudocount):
    return [contar(coluna, pseudocount) for coluna in zip(*seqs)]

def cria_perfil(contagens):
    return [cria_probabilidades(coluna) for coluna in contagens]

def cria_probabilidades(coluna):
    return {k : v / sum(coluna.values()) for k, v in coluna.items()}

def prod(lst):
    p = 1
    for x in lst:
        p *= x
    return p

class PWM:
    def __init__(self, seqs, pseudocount = 1):
        seqs = [s.upper() for s in seqs] # Será boa ideia?
        assert len(seqs) > 1, "There must be at least 2 sequences!"
        assert all(is_dna(s) for s in seqs), "At least one of the sequences is not DNA"
        assert all(len(s) == len(seqs[0]) for s in seqs), "At least one of the sequences has a different size"
        self.seqs = seqs
        self.pseudocount = pseudocount
        self.build_profile()
    def build_profile(self):
        contagens = faz_contagens(self.seqs, self.pseudocount)
        self.perfil = cria_perfil(contagens)
    def prob_gerado(self, seq):
        assert len(seq) == len(self.perfil), "A sequência não tem o mesmo tamanho do perfil!"
        return prod(p[x] for x, p in zip(seq, self.perfil))
    def seq_mais_provavel(self, seq):
        assert len(seq) >= len(self.perfil), "A sequência é mais pequena do que o perfil!"
        tam_perfil = len(self.perfil)
        dic_probs = {S : self.prob_gerado(S) for S in sliding_window(seq, tam_perfil)}
        return max(dic_probs, key = dic_probs.get)

class PSSM(PWM):
    def __init__(self, arg, pc = 1):
        if type(arg) is list:
            super().__init__(arg, pc)
        elif type(arg) is PWM:
            super().__init__(arg.seqs, pc)
        self.pssm = [{k : log2(v / (1/4)) for k, v in coluna.items()} for coluna in self.perfil]
    def score_seq(self, seq):
        assert len(seq) == len(self.perfil), "A sequência não tem o mesmo tamanho do perfil!"
        return sum(p[x] for x, p in zip(seq, self.pssm))
    def seq_mais_provavel(self, seq):
        assert len(seq) >= len(self.perfil), "A sequência é mais pequena do que o perfil!"
        tam_perfil = len(self.perfil)
        dic_probs = {S : self.score_seq(S) for S in sliding_window(seq, tam_perfil)}
        return max(dic_probs, key = dic_probs.get)
