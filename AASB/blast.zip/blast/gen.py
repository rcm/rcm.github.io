import random
def random_dna(size = 1000):
    return ''.join(random.choices("ACGT", k = size))
def mutate(S):
    return ''.join([X if random.random() < 0.1 else random.choice("ACGT") for X in S])

def inject_seq(Q, S):
    sz = random.randint(len(Q) // 8, 3 * len(Q) // 8)
    P = random.randint(len(Q) // 4, 3 * len(Q) // 4)
    QH = mutate(Q[:P])
    QE = Q[P : P + sz]
    QT = mutate(Q[P + sz:])
    P = random.randint(0, len(S))
    S = S[:P] + QH + QE + QT + S[P:]
    return S

def create_file(name, seq):
    with open(name, "w") as F:
        print(seq, file = F)

seqs = []
for qnum in range(10):
    query = random_dna(random.randint(600, 1000))
    qid = f"Q{qnum + 1:02d}"
    create_file(qid, query)
    for _ in range(random.randint(3, 8)):
        seq = random_dna(random.randint(400, 600)) 
        seq = inject_seq(query, seq)
        seqs.append(seq)

for N, S in enumerate(random.sample(seqs, len(seqs))):
    qid = f"S{N + 1:02d}"
    create_file(qid, S)
