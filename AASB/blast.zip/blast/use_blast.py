from blast import Blast
from glob import glob

B = Blast(N = 11)
for file in glob("S*"):
    B.insert_sequence(file)

with open("Q01") as F:
    Q = F.read().strip()
    print(B.find(Q))
