from pprint import pprint
from itertools import takewhile

from collections import defaultdict
def sliding_window(seq, N = 3):
    return [seq[P : P + N] for P in range(len(seq) - N + 1)]

def create_db(window):
    #dic = defaultdict(list)

    dic = {}
    for pos, seq in enumerate(window):
        if seq not in dic: dic[seq] = []
        dic[seq].append(pos)
    return dic

def create_struct(seq, N = 3):
    return create_db(sliding_window(seq, N))

def common_snip_offsets(SQ, SS, N = 3):
    common = set(SQ) & set(SS)
    dic = {}
    for snip in common:
        dic[snip] = [(o1, o2) for o1 in SQ[snip] for o2 in SS[snip]]
    return dic

def expand_dir(Q, S, PQ, PS, Dir, perc = 0.5):
    size = 0
    errors = 0
    dif = False
    while not dif and 0 <= PQ < len(Q) and 0 <= PS < len(S):
        CQ = Q[PQ]
        CS = S[PS]
        if CQ != CS:
            errors += 1
        PQ += Dir
        PS += Dir
        size += 1
        if errors >= perc * size:
            dif = True

    if dif:
        return PQ - Dir, PS - Dir
    else:
        return PQ, PS

def score(s1, s2):
    return sum(x1 == x2 for x1, x2 in zip(s1, s2))

def blast(Q, S, SQ, SS, N = 3):
    offset_dict = common_snip_offsets(SQ, SS, N)
    results = []
    for snip, offsets in offset_dict.items():
        for o1, o2 in offsets:
            b1, b2 = expand_dir(Q, S, o1, o2, -1)
            e1, e2 = expand_dir(Q, S, o1 + N, o2 + N, +1)
            assert e1 - b1 >= N  - 1 and e2 - b2 >= N - 1, f"{(b1,b2,e1,e2)} {Q[b1 - 1: e1 + 1]} {S[b2 - 1:e2 + 1]}"
            assert e1 - b1 == e2 - b2
            snipQ = Q[b1: e1 + 1]
            snipS = S[b2: e2 + 1]
            results.append(((b1, e1), (b2, e2), e1 - b1 + 1, score(snipQ, snipS)))
    sorted_results = sorted(results, key = lambda R : (-R[-1], R[-2]))
    if sorted_results:
        max_score = sorted_results[0][-1]
        return list(takewhile(lambda R : R[-1] == max_score, sorted_results))


class Blast:
    def __init__(self, N = 3):
        self.N = N
        self.seqs = {}
    def insert_sequence(self, name):
        with open(name) as F:
            seq = F.read().strip()
            self.seqs[name] = dict(seq = seq, struct = create_struct(seq, self.N))
    def find(self, query):
        results = []
        SQ = create_struct(query, self.N)
        for name, record in self.seqs.items():
            SS = record['struct']
            S = record['seq']
            seq_results = blast(query, S, SQ, SS, self.N)
            if seq_results:
                results.append((name, seq_results, seq_results[0][-1]))
        return sorted(results, key = lambda R : -R[-1])

